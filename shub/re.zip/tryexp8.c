#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>

#define MAX 5
#define ITEM 10

sem_t empty;
sem_t full;
sem_t mutex;
int buffer[MAX];
int count=0;

int in=0;
int out=0;

void *Producer(void *arg){
	for(int i=1; i<=ITEM; i++){
		int item = i*10;
		
		printf("Producer item generated\n");
		sem_wait(&empty);
		sem_wait(&mutex);
		
		buffer[in] = item;
		printf("Producer item inserted- %d\n", item);
		in = (in+1)%MAX;
		count++;
		sem_post(&mutex);
		sem_post(&full);
		sleep(1);	
	}
	return NULL;
}

void *Consumer(void *arg){
	int item;
	for(int i=1; i<=ITEM; i++){
		sem_wait(&full);
		sem_wait(&mutex);
		
		item = buffer[out];
		printf("Consumer had consumed- %d\n", item);
		out = (out+1)%MAX;
		count--;
		sem_post(&mutex);
		sem_post(&empty);
		printf("Consumer item delivered\n");
		sleep(1);
	}
	return NULL;
}

int main(){
	pthread_t prod;
	pthread_t cons;
	
	sem_init(&empty, 0, MAX);
	sem_init(&full, 0, 0);
	sem_init(&mutex, 0, 1);
	
	pthread_create(&prod, NULL, Producer, NULL);
	pthread_create(&cons, NULL, Consumer, NULL);
	
	pthread_join(prod, NULL);
	pthread_join(cons, NULL);
	printf("Orders Remaining to be delivered: %d\n", count);
	
	
	sem_destroy(&empty);
	sem_destroy(&full);
	sem_destroy(&mutex);
}



